VERSION: 2.0

Usage: 
```
UpDpad = Menu Open
      Melee = MenuClose
            Reload = Back
                  RTRIGGER = Up (I forgot)
                          LTRIGGER = Down (I forgot)
```

How To Install: Move _clientids. to ```~/t6r/data/maps/mp/gametypes/PASTEHERE```



I am active in this server: https://discord.gg/j3N6Wus9nH

So if you have any questions or anything like that ask me there.
